-- MySQL dump 10.13  Distrib 5.7.29, for Linux (x86_64)
--
-- Host: localhost    Database: appliAirbnb
-- ------------------------------------------------------
-- Server version	5.7.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES UTF8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `equipements`
--

DROP TABLE IF EXISTS `equipements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(255) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipements`
--

LOCK TABLES `equipements` WRITE;
/*!40000 ALTER TABLE `equipements` DISABLE KEYS */;
INSERT INTO `equipements` VALUES (1,'Produits de nettoyage','Salle de bain','produit.svg'),(2,'Shampooing','Salle de bain','shampooing.svg'),(3,'Douche extérieure','Salle de bain','douche-ex.svg'),(4,'Eau chaude','Salle de bain','eau-chaude.svg'),(5,'Lave-linge','Chambre et linge','lave-linge.svg'),(6,'Draps','Chambre et linge','draps.svg'),(7,'Oreillers et couvertures supplémentaires','Chambre et linge','oreiller.svg'),(8,'Stores','Chambre et linge','store.svg'),(9,'Fer à repasser','Chambre et linge','fer.svg'),(10,'Étendoir à linge','Chambre et linge','etendoir.svg'),(11,'TV HD','Divertissement','tv.svg'),(12,'Système audio','Divertissement','audio.svg'),(13,'Lit pour bébé','Famille','lit-baby.svg'),(14,'Lit parapluie','Famille','lit-parapluie.svg'),(15,'Jouets et livres pour enfants','Famille','jouet.svg'),(16,'Baignoire pour bébés','Famille','baignoir-baby.svg'),(17,'Vaisselle pour enfants','Famille','vaisselle-baby.svg'),(18,'Caches-prises','Famille','cache-prise.svg'),(19,'Barrières de sécurité pour bébé','Famille','security-barriere.svg'),(20,'Climatisation centrale','Chauffage et climisation','clim.svg'),(21,'Chauffage central','Chauffage et climisation','chauffage.svg'),(22,'Wi-Fi','Internet et bureau','wifi.svg'),(23,'Espace de travail','Internet et bureau','bureau.svg'),(24,'Cuisine','Cuisine et salle à manger','cuisine.svg'),(25,'Réfrigérateur','Cuisine et salle à manger','frigo.svg'),(26,'Four à micro-ondes','Cuisine et salle à manger','microndes.svg'),(27,'Équipements de cuisine de base','Cuisine et salle à manger','ustensible.svg'),(28,'Vaisselle et couverts','Cuisine et salle à manger','vaisselle.svg'),(29,'Four','Cuisine et salle à manger','four.svg'),(30,'Bouilloire électrique','Cuisine et salle à manger','bouilloire.svg'),(31,'Cafetière','Cuisine et salle à manger','cafetiere.svg'),(32,'Grille-pain','Cuisine et salle à manger','grille-pain.svg'),(33,'Table à manger','Cuisine et salle à manger','table-manger.svg'),(34,'Plaque de cuisson','Cuisine et salle à manger','plaque.svg'),(35,'Entrée privée','Caractéristiques','entrer.svg'),(36,'Entrée public','Caractéristiques','entrer.svg'),(37,'Privé : patio ou balcon','Extérieur','balcon.svg'),(38,'Mobilier extérieur','Extérieur','mobilier.svg'),(39,'Espace repas en plein air','Extérieur','mobilier.svg'),(40,'Barbecue','Extérieur','barbecue.svg'),(41,'Vélos','Extérieur','velo.svg'),(42,'Chaises longues','Extérieur','chaise-longue.svg'),(43,'Parking privé (2 places)','Parking et installations','voiture.svg'),(44,'Parking gratuit dans la rue','Parking et installations','voiture.svg');
/*!40000 ALTER TABLE `equipements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `information`
--

DROP TABLE IF EXISTS `information`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `information` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `zip_code` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `information`
--

LOCK TABLES `information` WRITE;
/*!40000 ALTER TABLE `information` DISABLE KEYS */;
INSERT INTO `information` VALUES (1,'13 Cami Vall Lloreres, France métropolitaine','4545454','0','France','668581561'),(2,'13 Cami Vall Lloreres, France métropolitaine','4545454','0','France','668581561'),(3,'13 Cami Vall Lloreres, France métropolitaine','4545454','0','France','668581561'),(4,'13 Cami Vall Lloreres, France métropolitaine','4545454','0','France','668581561'),(5,'13 Cami Vall Lloreres, France métropolitaine','4545454','0','France','668581561');
/*!40000 ALTER TABLE `information` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logement`
--

DROP TABLE IF EXISTS `logement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `price` float NOT NULL,
  `nb_rooms` int(11) NOT NULL,
  `nb_traveler` int(11) NOT NULL,
  `size` int(11) NOT NULL,
  `information_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type_logement_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `information_id` (`information_id`),
  KEY `user_id` (`user_id`),
  KEY `type_logement_id` (`type_logement_id`),
  CONSTRAINT `logement_ibfk_1` FOREIGN KEY (`information_id`) REFERENCES `information` (`id`),
  CONSTRAINT `logement_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `logement_ibfk_3` FOREIGN KEY (`type_logement_id`) REFERENCES `typeLogement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logement`
--

LOCK TABLES `logement` WRITE;
/*!40000 ALTER TABLE `logement` DISABLE KEYS */;
/*!40000 ALTER TABLE `logement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logement_equipement`
--

DROP TABLE IF EXISTS `logement_equipement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logement_equipement` (
  `logement_id` int(11) NOT NULL,
  `equipement_id` int(11) NOT NULL,
  KEY `logement_id` (`logement_id`),
  KEY `equipement_id` (`equipement_id`),
  CONSTRAINT `logement_equipement_ibfk_1` FOREIGN KEY (`logement_id`) REFERENCES `logement` (`id`),
  CONSTRAINT `logement_equipement_ibfk_2` FOREIGN KEY (`equipement_id`) REFERENCES `equipements` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logement_equipement`
--

LOCK TABLES `logement_equipement` WRITE;
/*!40000 ALTER TABLE `logement_equipement` DISABLE KEYS */;
/*!40000 ALTER TABLE `logement_equipement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(255) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `logement_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `logement_id` (`logement_id`),
  CONSTRAINT `media_ibfk_1` FOREIGN KEY (`logement_id`) REFERENCES `logement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reservation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_number` varchar(255) NOT NULL,
  `date_start` varchar(255) NOT NULL,
  `date_end` varchar(255) NOT NULL,
  `nb_adults` int(11) NOT NULL,
  `nb_child` int(11) NOT NULL,
  `price_total` float NOT NULL,
  `logement_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `logement_id` (`logement_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `reservation_ibfk_1` FOREIGN KEY (`logement_id`) REFERENCES `logement` (`id`),
  CONSTRAINT `reservation_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation`
--

LOCK TABLES `reservation` WRITE;
/*!40000 ALTER TABLE `reservation` DISABLE KEYS */;
/*!40000 ALTER TABLE `reservation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `typeLogement`
--

DROP TABLE IF EXISTS `typeLogement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `typeLogement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(255) NOT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `typeLogement`
--

LOCK TABLES `typeLogement` WRITE;
/*!40000 ALTER TABLE `typeLogement` DISABLE KEYS */;
INSERT INTO `typeLogement` VALUES (1,'Propriété entière','ff',1);
/*!40000 ALTER TABLE `typeLogement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_verified` tinyint(1) NOT NULL DEFAULT '0',
  `information_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `information_id` (`information_id`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`information_id`) REFERENCES `information` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'fgalinier51@gmail.com','Admin1234',NULL,NULL,1,1,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-14 14:52:08
